// This if for Jest to fully support ESM, for testing
export default {
  presets: [['@babel/preset-env', { targets: { node: 'current' } }]],
};

